package com.deepesh.payroll.service.implementaion;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.deepesh.payroll.Repo.SalaryBreakupRepository;
import com.deepesh.payroll.dao.SalaryBreakupDao;
import com.deepesh.payroll.model.Employee;
import com.deepesh.payroll.model.SalaryBreakup;
import com.deepesh.payroll.service.SalaryBreakupService;

@Service
public class SalaryBreakupServiceImplementation implements SalaryBreakupService {
	
	@Autowired
	private SalaryBreakupRepository salaryBreakupRepo;
	
	
	Employee emp = new Employee();
	
	@Override
	
	
	//get all
	public List<SalaryBreakup> getAllSalaryBreakup() {
		return salaryBreakupRepo.findAll();
	}
	
	
	//SaveData
	@Override
	public ResponseEntity<?> saveData(SalaryBreakupDao salarybk) {
		
		SalaryBreakup dep = new SalaryBreakup(salarybk.getBasicsalary(),salarybk.getHouserentallowance(),salarybk.getConveyanceallowance(),salarybk.getMedicalallowance(),
				salarybk.getSpecialallowance(),salarybk.getEpf(), salarybk.getHealthinsurance(),salarybk.getTenantid(),salarybk.getSalaryfor() );
		salaryBreakupRepo.save(dep);
		return ResponseEntity.ok(dep);
	}

	
	@Override
	public void deleteById(Integer id) {
		
	if(salaryBreakupRepo.findById(id)!=null)
	{
		salaryBreakupRepo.deleteById(id);
	}
	
}

	@Override
	public SalaryBreakup getSalBreakupByID(Integer id) {

		return salaryBreakupRepo.getByID(id);
	}

	
}