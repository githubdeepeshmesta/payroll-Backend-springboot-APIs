package com.deepesh.payroll.dao;
public class EmployeDao {

	private int empid;
	
	private String empFullName;
	private String empEmail;
	private String empAddress;
	private String phoNumber;
	private String bloodGroup;
	private String dept;
	private String empPresentJobPosition;
	private SalaryDao salaryDao;
	private EmployeeDetailsDao employeeDetailsDao;
	private String tenantid;
	
	
	public String getTenantid() {
		return tenantid;
	}
	public void setTenantid(String tenantid) {
		this.tenantid = tenantid;
	}
	public SalaryDao getSalaryDao() {
		return salaryDao;
	}
	public void setSalaryDao(SalaryDao salaryDao) {
		this.salaryDao = salaryDao;
	}
	public EmployeeDetailsDao getEmployeeDetailsDao() {
		return employeeDetailsDao;
	}
	
	public void setEmployeeDetailsDao(EmployeeDetailsDao employeeDetailsDao) {
		this.employeeDetailsDao = employeeDetailsDao;
	}
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpFullName() {
		return empFullName;
	}
	public void setEmpFullName(String empFullName) {
		this.empFullName = empFullName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	public String getPhoNumber() {
		return phoNumber;
	}
	public void setPhoNumber(String phoNumber) {
		this.phoNumber = phoNumber;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getEmpPresentJobPosition() {
		return empPresentJobPosition;
	}
	public void setEmpPresentJobPosition(String empPresentJobPosition) {
		this.empPresentJobPosition = empPresentJobPosition;
	}

	
}
