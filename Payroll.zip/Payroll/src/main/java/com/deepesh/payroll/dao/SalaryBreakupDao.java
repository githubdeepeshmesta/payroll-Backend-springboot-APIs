package com.deepesh.payroll.dao;

public class SalaryBreakupDao {
	
	private Double bid;
	private Double basicsalary;
	private Double houserentallowance;
	private Double conveyanceallowance;
	private Double medicalallowance;
	private Double specialallowance;
	private Double epf;
	private Double healthinsurance;
	private String tenantid;
	private String salaryfor;
	
	
	public String getTenantid() {
		return tenantid;
	}
	public void setTenantid(String tenantid) {
		this.tenantid = tenantid;
	}
	public String getSalaryfor() {
		return salaryfor;
	}
	public void setSalaryfor(String salaryfor) {
		this.salaryfor = salaryfor;
	}
	public Double getBid() {
		return bid;
	}
	public void setBid(Double bid) {
		this.bid = bid;
	}
	public Double getBasicsalary() {
		return basicsalary;
	}
	public void setBasicsalary(Double basicsalary) {
		this.basicsalary = basicsalary;
	}
	public Double getHouserentallowance() {
		return houserentallowance;
	}
	public void setHouserentallowance(Double houserentallowance) {
		this.houserentallowance = houserentallowance;
	}
	public Double getConveyanceallowance() {
		return conveyanceallowance;
	}
	public void setConveyanceallowance(Double conveyanceallowance) {
		this.conveyanceallowance = conveyanceallowance;
	}
	public Double getMedicalallowance() {
		return medicalallowance;
	}
	public void setMedicalallowance(Double medicalallowance) {
		this.medicalallowance = medicalallowance;
	}
	public Double getSpecialallowance() {
		return specialallowance;
	}
	public void setSpecialallowance(Double specialallowance) {
		this.specialallowance = specialallowance;
	}
	public Double getEpf() {
		return epf;
	}
	public void setEpf(Double epf) {
		this.epf = epf;
	}
	public Double getHealthinsurance() {
		return healthinsurance;
	}
	public void setHealthinsurance(Double healthinsurance) {
		this.healthinsurance = healthinsurance;
	}	
}
