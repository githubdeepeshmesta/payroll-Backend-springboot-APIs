package com.deepesh.payroll.model;

import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "EmployeeDetails")
public class EmployeeDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "eid")
	private Integer eid;
	private BigInteger emergencyphoNumber;
	private String empLearningInstitution;
	private String empLastJobPosition;
	private String empHealthCondition;
	private String empSpecialSkills;
	private String bankName;
	private long bankNo;
	private String tenantid;

	public EmployeeDetails() {
		}

	public EmployeeDetails(BigInteger emergencyphoNumber, String empLearningInstitution, String empLastJobPosition,
			String empHealthCondition, String empSpecialSkills, String bankName, long bankNo, String tenantid) {
		super();
		this.emergencyphoNumber = emergencyphoNumber;
		this.empLearningInstitution = empLearningInstitution;
		this.empLastJobPosition = empLastJobPosition;
		this.empHealthCondition = empHealthCondition;
		this.empSpecialSkills = empSpecialSkills;
		this.bankName = bankName;
		this.bankNo = bankNo;
		this.tenantid = tenantid;
	}

	public String getTenantid() {
		return tenantid;
	}

	public void setTenantid(String tenantid) {
		this.tenantid = tenantid;
	}

	public Integer getEid() {
		return eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public BigInteger getEmergencyphoNumber() {
		return emergencyphoNumber;
	}

	public void setEmergencyphoNumber(BigInteger emergencyphoNumber) {
		this.emergencyphoNumber = emergencyphoNumber;
	}

	public String getEmpLearningInstitution() {
		return empLearningInstitution;
	}

	public void setEmpLearningInstitution(String empLearningInstitution) {
		this.empLearningInstitution = empLearningInstitution;
	}

	public String getEmpLastJobPosition() {
		return empLastJobPosition;
	}

	public void setEmpLastJobPosition(String empLastJobPosition) {
		this.empLastJobPosition = empLastJobPosition;
	}

	public String getEmpHealthCondition() {
		return empHealthCondition;
	}

	public void setEmpHealthCondition(String empHealthCondition) {
		this.empHealthCondition = empHealthCondition;
	}

	public String getEmpSpecialSkills() {
		return empSpecialSkills;
	}

	public void setEmpSpecialSkills(String empSpecialSkills) {
		this.empSpecialSkills = empSpecialSkills;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public long getBankNo() {
		return bankNo;
	}

	public void setBankNo(long bankNo) {
		this.bankNo = bankNo;
	}

}
