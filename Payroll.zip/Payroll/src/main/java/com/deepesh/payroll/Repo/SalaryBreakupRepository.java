package com.deepesh.payroll.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.deepesh.payroll.model.SalaryBreakup;

public interface SalaryBreakupRepository extends JpaRepository<SalaryBreakup, Integer> {

	// delete by data from Department
	@Query("delete from SalaryBreakup u where u.bid=:id")
	SalaryBreakup deleteByID(Integer id);

	@Query("Select d from SalaryBreakup d where d.bid=:id")
	SalaryBreakup getByID(Integer id);

}
