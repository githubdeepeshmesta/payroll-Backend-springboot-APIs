package com.deepesh.payroll.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.deepesh.payroll.dao.EmployeDao;
import com.deepesh.payroll.model.Employee;
import com.deepesh.payroll.service.EmployeeService;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	//Adding
	@PostMapping("/addDetails")
	private ResponseEntity<?> saveDetails(@RequestBody EmployeDao emp) {
		try {
			 return employeeService.saveData(emp);

		}
		catch(Exception ex) {
			return ResponseEntity.ok(ex.getMessage());
		}
	}

	// show all details
	@GetMapping("/all")
	private List<Employee> getAllEmployeeDetails() {
		return employeeService.getAllEmployees();
	}

	// get Employee by ID
	@GetMapping("/getEmp/{id}")
	public Employee getEmpId(@PathVariable Integer id) {
		System.out.println(id);
		Employee emp = employeeService.getEmployeeByID(id);
		return emp;
	};

	// delete one Employee data
	@DeleteMapping("/delEmp/{id}")
	private String deleteEmployee(@PathVariable Integer id) {
		employeeService.deleteById(id);
		return "Sucessfully deleted... :( ";
	}

	// Update using id
	@PutMapping("updateEmp/{id}")
	private Employee updateEmpById(@PathVariable Integer id, @RequestBody Employee employee) {
		Employee emp = employeeService.getEmployeeByID(id);
		emp.getEmpid();
		emp.setEmpFullName(employee.getEmpFullName());
		emp.setEmpEmail(employee.getEmpEmail());
		emp.setEmpAddress(employee.getEmpAddress());
		emp.setPhoNumber(employee.getPhoNumber());
		emp.setBloodGroup(employee.getBloodGroup());
		emp.setEmpPresentJobPosition(employee.getEmpPresentJobPosition());
		emp.setDept(employee.getDept());
		emp.setEmpployeeDetails(employee.getEmpployeeDetails());
		emp.setTenantid(employee.getTenantid());
		emp.setSalary(employee.getSalary());
		employeeService.updateEmp(emp);
		return emp;

	}
}
