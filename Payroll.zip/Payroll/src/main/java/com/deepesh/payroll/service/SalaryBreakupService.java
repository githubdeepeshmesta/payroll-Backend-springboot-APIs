package com.deepesh.payroll.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.deepesh.payroll.dao.SalaryBreakupDao;
import com.deepesh.payroll.model.SalaryBreakup;

public interface SalaryBreakupService {

	List<SalaryBreakup> getAllSalaryBreakup();

	ResponseEntity<?> saveData(SalaryBreakupDao dept);

	public void deleteById(Integer id);

	SalaryBreakup getSalBreakupByID(Integer id);

	
}
	
