package com.deepesh.payroll.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.deepesh.payroll.model.Salary;
@Repository
public interface SalaryRepositoy extends JpaRepository<Salary, Integer>{

}
