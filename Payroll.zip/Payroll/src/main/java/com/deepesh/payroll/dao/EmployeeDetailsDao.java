package com.deepesh.payroll.dao;

import java.math.BigInteger;

public class EmployeeDetailsDao {
	private Integer eid;
	private String empLearningInstitution;
	private String empLastJobPosition;
	private String empHealthCondition;
	private String empSpecialSkills;
	private String bankName;
	private long bankNo;
	private BigInteger emergencyphoNumber;
	private String tenantid;
	
	
	
	public String getTenantid() {
		return tenantid;
	}
	public void setTenantid(String tenantid) {
		this.tenantid = tenantid;
	}
	public BigInteger getEmergencyphoNumber() {
		return emergencyphoNumber;
	}
	public void setEmergencyphoNumber(BigInteger emergencyphoNumber) {
		this.emergencyphoNumber = emergencyphoNumber;
	}
	public Integer getEid() {
		return eid;
	}
	public void setEid(Integer eid) {
		this.eid = eid;
	}
	public String getEmpLearningInstitution() {
		return empLearningInstitution;
	}
	public void setEmpLearningInstitution(String empLearningInstitution) {
		this.empLearningInstitution = empLearningInstitution;
	}
	public String getEmpLastJobPosition() {
		return empLastJobPosition;
	}
	public void setEmpLastJobPosition(String empLastJobPosition) {
		this.empLastJobPosition = empLastJobPosition;
	}
	public String getEmpHealthCondition() {
		return empHealthCondition;
	}
	public void setEmpHealthCondition(String empHealthCondition) {
		this.empHealthCondition = empHealthCondition;
	}
	public String getEmpSpecialSkills() {
		return empSpecialSkills;
	}
	public void setEmpSpecialSkills(String empSpecialSkills) {
		this.empSpecialSkills = empSpecialSkills;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public long getBankNo() {
		return bankNo;
	}
	public void setBankNo(long bankNo) {
		this.bankNo = bankNo;
	}
	

}
