package com.deepesh.payroll.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "Salary")
public class Salary {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sid;
	private Double basicSalary;
	private Double houseRentAllowances;
	private Double conveyanceAllowances;
	private Double medicalAllowances;
	private Double specialAllowances;
	private Double grossSalary;
	private Double epf;
	private Double healthInsurance;
	private Double professionalTax;
	private Double totalDeduction;
	private String tenantid;
	private Double netpay;
	private String salaryfor;
	
	
	
	
	public Salary(Double basicSalary, Double houseRentAllowances, Double conveyanceAllowances, Double medicalAllowances,
			Double specialAllowances, Double grossSalary, Double epf, Double healthInsurance, Double professionalTax,
			Double totalDeduction, String tenantid,Double netpay,String salaryfor) {
		
		this.basicSalary = basicSalary;
		this.houseRentAllowances = houseRentAllowances;
		this.conveyanceAllowances = conveyanceAllowances;
		this.medicalAllowances = medicalAllowances;
		this.specialAllowances = specialAllowances;
		this.grossSalary = grossSalary;
		this.epf = epf;
		this.healthInsurance = healthInsurance;
		this.professionalTax = professionalTax;
		this.totalDeduction = totalDeduction;
		this.tenantid = tenantid;
		this.netpay = netpay;
		this.salaryfor=salaryfor;
	}

	
	public String getSalaryfor() {
		return salaryfor;
	}


	public void setSalaryfor(String salaryfor) {
		this.salaryfor = salaryfor;
	}


	public Double getNetpay() {
		return netpay;
	}
	public void setNetpay(Double netpay) {
		this.netpay = netpay;
	}
	public Salary() {
		
	}
	public String getTenantid() {
		return tenantid;
	}

	public void setTenantid(String tenantid) {
		this.tenantid = tenantid;
	}

	public Integer getSid() {
		return sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	
	
	public Double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public Double getHouseRentAllowances() {
		return houseRentAllowances;
	}
	public void setHouseRentAllowances(Double houseRentAllowances) {
		this.houseRentAllowances = houseRentAllowances;
	}
	public Double getConveyanceAllowances() {
		return conveyanceAllowances;
	}
	public void setConveyanceAllowances(Double conveyanceAllowances) {
		this.conveyanceAllowances = conveyanceAllowances;
	}
	public Double getMedicalAllowances() {
		return medicalAllowances;
	}
	public void setMedicalAllowances(Double medicalAllowances) {
		this.medicalAllowances = medicalAllowances;
	}
	public Double getSpecialAllowances() {
		return specialAllowances;
	}
	public void setSpecialAllowances(Double specialAllowances) {
		this.specialAllowances = specialAllowances;
	}
	public Double getGrossSalary() {

		return grossSalary;
	}
	public void setGrossSalary(Double grossSalary) {
		this.grossSalary = grossSalary;
	}
	public Double getEpf() {
		return epf;
	}
	public void setEpf(Double epf) {
		this.epf = epf;
	}
	public Double getHealthInsurance() {
		return healthInsurance;
	}
	public void setHealthInsurance(Double healthInsurance) {
		this.healthInsurance = healthInsurance;
	}
	public Double getProfessionalTax() {
//		if(grossSalary > 50000) {
//			professionalTax = grossSalary * 10/100;
//		}
//		else if(grossSalary > 50000)
//		{
//			professionalTax = grossSalary * 10/100;
//		}
//		else {
//			professionalTax = 0.0;
//		}
		return professionalTax;
	}
	public void setProfessionalTax(Double professionalTax) {
		this.professionalTax = professionalTax;
	}
	public Double getTotalDeduction() {
		return totalDeduction;
	}
	
	public void setTotalDeduction(Double totalDeduction) {
		this.totalDeduction = totalDeduction;
	}
}
