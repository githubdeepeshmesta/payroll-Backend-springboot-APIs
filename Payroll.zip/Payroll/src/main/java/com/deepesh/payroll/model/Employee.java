package com.deepesh.payroll.model;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity(name = "Employee")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="empid")
	private int empid;
	
	private String empFullName;
	private String empEmail;
	private String empAddress;
	private String phoNumber;
	private String bloodGroup;
	private String dept;
	private String empPresentJobPosition;
	private String tenantid;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Salary salary;

	@OneToOne(cascade = CascadeType.ALL)
	private EmployeeDetails empployeeDetails;

	public Employee() {
	super();
	}
	
	
	public Employee(String empFullName, String empEmail, String empAddress, String phoNumber, String bloodGroup,
			String dept, String empPresentJobPosition, String tenantid, Salary salary,
			EmployeeDetails empployeeDetails) {
	
		this.empFullName = empFullName;
		this.empEmail = empEmail;
		this.empAddress = empAddress;
		this.phoNumber = phoNumber;
		this.bloodGroup = bloodGroup;
		this.dept = dept;
		this.empPresentJobPosition = empPresentJobPosition;
		this.tenantid = tenantid;
		this.salary = salary;
		this.empployeeDetails = empployeeDetails;
	}


	public String getTenantid() {
		return tenantid;
	}


	public void setTenantid(String tenantid) {
		this.tenantid = tenantid;
	}


	public Salary getSalary() {
		return salary;
	}

	public void setSalary(Salary salary) {
		this.salary = salary;
	}


	public EmployeeDetails getEmpployeeDetails() {
		return empployeeDetails;
	}

	public void setEmpployeeDetails(EmployeeDetails empployeeDetails) {
		this.empployeeDetails = empployeeDetails;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpFullName() {
		return empFullName;
	}

	public void setEmpFullName(String empFullName) {
		this.empFullName = empFullName;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getEmpPresentJobPosition() {
		return empPresentJobPosition;
	}

	public void setEmpPresentJobPosition(String empPresentJobPosition) {
		this.empPresentJobPosition = empPresentJobPosition;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public String getPhoNumber() {
		return phoNumber;
	}

	public void setPhoNumber(String phoNumber) {
		this.phoNumber = phoNumber;
	}

}
