package com.deepesh.payroll.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.deepesh.payroll.dao.EmployeDao;
import com.deepesh.payroll.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();

	ResponseEntity<?> saveData(EmployeDao emp);

	Employee getEmployeeByID(Integer id);

	void deleteById(Integer id);

	Employee updateEmp(Employee employee);

	

}
