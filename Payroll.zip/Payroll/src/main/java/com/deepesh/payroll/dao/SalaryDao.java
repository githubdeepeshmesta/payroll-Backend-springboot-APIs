package com.deepesh.payroll.dao;

public class SalaryDao {
	private Integer sid;
	private Double basicSalary;
	private Double houseRentAllowances;
	private Double conveyanceAllowances;
	private Double medicalAllowances;
	private Double specialAllowances;
	private Double grossSalary;
	private Double epf;
	private Double healthInsurance;
	private Double professionalTax;
	private Double totalDeduction;
	private String tenantid;
	private Double netpay;
	private String salaryfor;
	
	
	public String getSalaryfor() {
		return salaryfor;
	}
	public void setSalaryfor(String salaryfor) {
		this.salaryfor = salaryfor;
	}
	public Double getNetpay() {
		return netpay;
	}
	public void setNetpay(Double netpay) {
		this.netpay = netpay;
	}
	public String getTenantid() {
		return tenantid;
	}
	public void setTenantid(String tenantid) {
		this.tenantid = tenantid;
	}
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public Double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}
	public Double getHouseRentAllowances() {
		return houseRentAllowances;
	}
	public void setHouseRentAllowances(Double houseRentAllowances) {
		this.houseRentAllowances = houseRentAllowances;
	}
	public Double getConveyanceAllowances() {
		return conveyanceAllowances;
	}
	public void setConveyanceAllowances(Double conveyanceAllowances) {
		this.conveyanceAllowances = conveyanceAllowances;
	}
	public Double getMedicalAllowances() {
		return medicalAllowances;
	}
	public void setMedicalAllowances(Double medicalAllowances) {
		this.medicalAllowances = medicalAllowances;
	}
	public Double getSpecialAllowances() {
		return specialAllowances;
	}
	public void setSpecialAllowances(Double specialAllowances) {
		this.specialAllowances = specialAllowances;
	}
	public Double getGrossSalary() {
	
		return grossSalary;
	}
	public void setGrossSalary(Double grossSalary) {
		this.grossSalary = grossSalary;
	}
	public Double getEpf() {
		return epf;
	}
	public void setEpf(Double epf) {
		this.epf = epf;
	}
	public Double getHealthInsurance() {
		return healthInsurance;
	}
	public void setHealthInsurance(Double healthInsurance) {
		this.healthInsurance = healthInsurance;
	}
	public Double getProfessionalTax() {
		return professionalTax;
	}
	public void setProfessionalTax(Double professionalTax) {
		this.professionalTax = professionalTax;
	}
	public Double getTotalDeduction() {
		return totalDeduction;
	}
	public void setTotalDeduction(Double totalDeduction) {
		this.totalDeduction = totalDeduction;
	}
	
}
