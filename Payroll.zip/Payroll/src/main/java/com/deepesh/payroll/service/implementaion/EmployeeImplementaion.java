package com.deepesh.payroll.service.implementaion;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.deepesh.payroll.Repo.EmployeeRepository;
import com.deepesh.payroll.dao.EmployeDao;
import com.deepesh.payroll.model.Employee;
import com.deepesh.payroll.model.EmployeeDetails;
import com.deepesh.payroll.model.Salary;
import com.deepesh.payroll.service.EmployeeService;

@Service
public class EmployeeImplementaion implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	public EmployeeImplementaion(EmployeeRepository employeeRepository) {
		
		this.employeeRepository = employeeRepository;
	}
	
	//getallData
	@Override
	public List<Employee> getAllEmployees() 
	{	
		return employeeRepository.findAll();
	}
	
	
	//saveData
	@Override
	public ResponseEntity<?> saveData(EmployeDao emp) {
		Employee newemp = new Employee();
		
		//Salary to SalaryDao
		Salary salary = new Salary(emp.getSalaryDao().getBasicSalary(), emp.getSalaryDao().getHouseRentAllowances(), emp.getSalaryDao().getConveyanceAllowances(), emp.getSalaryDao().getMedicalAllowances(),
				emp.getSalaryDao().getSpecialAllowances(), emp.getSalaryDao().getGrossSalary(), emp.getSalaryDao().getEpf(), emp.getSalaryDao().getHealthInsurance(), emp.getSalaryDao().getProfessionalTax(),
				emp.getSalaryDao().getTotalDeduction(), emp.getTenantid(),emp.getSalaryDao().getNetpay(),emp.getSalaryDao().getSalaryfor());	
		
		newemp.setSalary(salary); 
		
		
		//EmployeeDetails to EmployeeDetailsDao
		EmployeeDetails employeeDetails = new EmployeeDetails(emp.getEmployeeDetailsDao().getEmergencyphoNumber(), emp.getEmployeeDetailsDao().getEmpLearningInstitution(), emp.getEmployeeDetailsDao().getEmpLastJobPosition(),
				emp.getEmployeeDetailsDao().getEmpHealthCondition(), emp.getEmployeeDetailsDao().getEmpSpecialSkills(), emp.getEmployeeDetailsDao().getBankName() , emp.getEmployeeDetailsDao().getBankNo(), emp.getTenantid());
		
		newemp.setEmpployeeDetails(employeeDetails);
		
		//Employee
		newemp = new Employee(emp.getEmpFullName(), emp.getEmpEmail(), emp.getEmpAddress(), emp.getPhoNumber(), emp.getBloodGroup(),
				emp.getDept(), emp.getEmpPresentJobPosition(), emp.getTenantid(), salary, employeeDetails);
		
		employeeRepository.save(newemp);
		
		return ResponseEntity.ok(newemp);
	}

	@Override
	public Employee getEmployeeByID(Integer id) {
		
		return employeeRepository.findByID(id);
	}

	@Override
	public void deleteById(Integer id) {
		if(employeeRepository.findByID(id) != null)
		{
			employeeRepository.deleteById(id);
		}else {
			
		}		
	}

	@Override
	public Employee updateEmp(Employee employee) 
	{
		return employeeRepository.save(employee);
	}
	
	
	
}
